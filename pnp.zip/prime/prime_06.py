max_number = 2000

candidates = range(2, max_number + 1)

for sieve_number in range(2, (max_number + 2) / 2):
	if sieve_number not in candidates:
		continue
	sieve_multiplicator_iterator = iter(candidates[candidates.index(sieve_number):])
	sieve_multiplicator = sieve_multiplicator_iterator.next()
	while sieve_number * sieve_multiplicator <= max_number:
		candidates.remove(sieve_number * sieve_multiplicator)
		sieve_multiplicator = sieve_multiplicator_iterator.next()

for number in candidates:
	print number