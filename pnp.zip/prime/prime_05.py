max_number = 2000

def number_is_prime(number):
	for test_divisor in range(2, number):
		if number % test_divisor == 0:
			return False
	return True

for number in range(2, max_number + 1):
	if number_is_prime(number):
		print number