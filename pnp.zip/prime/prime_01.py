max_number = 20

print range(max_number)
print range(1, max_number + 1)
print range(2, max_number + 1)

print 13 % 3