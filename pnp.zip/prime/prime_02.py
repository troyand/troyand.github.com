max_number = 20

for i in range(2, max_number + 1):
	print i