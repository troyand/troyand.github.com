max_number = 2000

for number in range(2, max_number + 1):
	number_is_prime = True
	for test_divisor in range(2, number):
		if number % test_divisor == 0:
			number_is_prime = False
	if number_is_prime:
		print number