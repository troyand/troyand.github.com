count = 10

for i in range(count):
	print 'I WILL NOT SEAT ON KORABLYK RAILING'