import sys
import time

count = 10

for i in range(count):
	for letter in 'I WILL NOT SEAT ON KORABLYK RAILING':
		sys.stdout.write(letter)
		sys.stdout.flush()
		time.sleep(0.15)
	sys.stdout.write('\n')