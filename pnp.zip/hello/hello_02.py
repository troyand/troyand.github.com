name = 'Alice'

print 'Hello', name
