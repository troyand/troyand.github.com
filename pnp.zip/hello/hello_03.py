name = 'Bob'

if name == 'Bob':
	print 'Hi', name
else:
	print 'Hello', name
