name = 'Charlie'

if name == 'Bob':
	print 'Hi', name
elif name == 'Charlie':
	print 'What\'s up', name
else:
	print 'Hello', name
