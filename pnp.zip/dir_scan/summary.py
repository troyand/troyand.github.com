# -*- coding: utf8 -*- 

import os
import codecs

TOP_DIR = './data'

years = range(2009, 2013)

months = range(1, 13)

meat_count = 0
bun_count = 0
tea_count = 0

locations = ['east', 'west', 'north', 'south']

for year in sorted(os.listdir(TOP_DIR)):
    #print year
    for month in sorted(os.listdir(os.path.join(TOP_DIR, year))):
        #print month
        for location in locations:
            try:
                summary = codecs.open(os.path.join(
                    TOP_DIR,
                    year,
                    month,
                    location +'.txt'),
                'r',
                'utf8'
                )

                for line in summary:
                    name, count = line.split(' = ')
                    if name == u'м\'ясо під сиром':
                        meat_count = meat_count + int(count)
                    elif name == u'булка із корицею':
                        bun_count = bun_count + int(count)
                    elif name == u'чай чорнявий':
                        tea_count = tea_count + int(count)
            except IOError:
                print '%s-%s does not have report for %s' % (
                        year,
                        month,
                        location,
                        )

print u'м\'ясо під сиром =', meat_count
print u'булка із корицею =', bun_count
print u'чай чорнявий =', tea_count
